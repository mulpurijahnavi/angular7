import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-routingcomp',
  templateUrl: './routingcomp.component.html',
  styleUrls: ['./routingcomp.component.css']
})
export class RoutingcompComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
